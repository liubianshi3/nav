# A2 新手启动指南

这份文档只解决一件事：

- 让第一次接手 A2 的人，按步骤把这套网页导航系统启动起来

默认前提：

- 你已经能 `ssh` 到 A2
- A2 机器上的工作区路径是 `/home/unitree/a2_system_ws`
- 当前推荐运行方式是 Docker

---

## 1. 这套系统是什么

这套系统分两层：

1. A2 真机底层
   - 雷达
   - SDK
   - `/odom`
   - `/a2/raw_state`

2. `a2_system_ws`
   - 建图模式
   - 导航模式
   - Web 控制台
   - 地图保存与切换

网页入口默认是：

```text
http://192.168.31.49:8080/
```

如果 A2 的局域网 IP 变了，就把 `192.168.31.49` 换成当前机器 IP。

---

## 2. 先做最小检查

先登录 A2：

```bash
ssh unitree@192.168.31.49
```

确认工作区存在：

```bash
cd /home/unitree/a2_system_ws
pwd
```

确认 Docker 可用：

```bash
docker --version
docker compose version
```

如果这两句报错，先不要继续，先把 Docker 环境补齐。

---

## 3. 第一次启动前建议先清场

先把旧容器和旧栈停掉，避免残留干扰。

### 3.1 停掉 Docker 容器

```bash
cd /home/unitree/a2_system_ws
docker compose -f docker/docker-compose.a2.yml down
```

### 3.2 停掉老的宿主 Web 服务

```bash
sudo systemctl stop a2-web-console.service
```

### 3.3 看是否还有旧导航进程残留

```bash
pgrep -af "bringup.launch.py|a2_sdk_bridge|a2_control_bridge|manual_localization_publisher|goal_bridge|map_server|bt_navigator|planner_server|controller_server|velocity_smoother|lifecycle_manager|occupancy_mapper|map_manager"
```

正常情况应该没有输出。

如果这里还有输出，先执行：

```bash
source /opt/ros/humble/setup.bash
source /home/unitree/a2_system_ws/install/setup.bash
/home/unitree/a2_system_ws/install/a2_system/share/a2_system/stop_stack.sh
```

然后再检查一次。

---

## 4. 第一次部署或代码更新后怎么启动

### 4.1 进入工作区

```bash
cd /home/unitree/a2_system_ws
```

### 4.2 重建 Docker 镜像

```bash
./docker/build_real_image.sh
```

说明：

- 第一次构建会比较慢，几分钟是正常的
- 这一步会把 A2 本机的 `/opt/unitree_robotics` 一起打进镜像

### 4.3 启动容器

```bash
docker compose -f docker/docker-compose.a2.yml up -d --force-recreate
```

### 4.4 检查容器是否起来

```bash
docker ps
```

应该能看到：

- `docker-a2-system-ws-1`

### 4.5 检查后端健康状态

```bash
curl http://127.0.0.1:8080/api/health
```

如果后端刚启动，可能先看到：

- `backend_ok=true`
- `ros_connected=true`
- `action_server_ready=false`
- `map_received=false`
- `pose_received=false`

这不一定是故障，只说明栈还没开始跑。

---

## 5. 日常启动最短流程

如果镜像已经构建过，平时只需要这两句：

```bash
cd /home/unitree/a2_system_ws
docker compose -f docker/docker-compose.a2.yml up -d
```

然后浏览器打开：

```text
http://192.168.31.49:8080/
```

---

## 6. 网页怎么用

网页里最重要的是两种模式：

1. 建图模式
2. 导航模式

### 6.1 建图模式

用途：

- 新场地第一次扫图
- 原地图不能用，重新建图

操作顺序：

1. 打开网页
2. 点击“启动建图模式”
3. 等左侧节点状态变成 `running`
4. 用遥控器或你的控制方式，慢速带机器人走一圈
5. 地图扫得差不多后，在右侧输入地图名
6. 点击“保存当前地图”

重要提醒：

- 建图模式不会自动让机器人运动
- 你必须手动带它走
- 建图时尽量慢走，少急转，尽量形成闭环

### 6.2 导航模式

用途：

- 使用已经保存好的地图做定位和导航

操作顺序：

1. 在右侧“导航地图”下拉框里选一张地图
2. 点击“启动导航模式”
3. 等左侧节点状态都变成 `running`
4. 在地图上点击机器人当前所在位置
5. 点击“设置初始位姿”
6. 再在地图上点击一个目标点
7. 点击“发送导航目标”

如果要停止当前任务：

```text
点击网页上的“停止当前栈”或“停止导航”
```

---

## 7. 新手最容易搞混的几个点

### 7.1 “启动容器”不等于“已经开始导航”

容器起来，只代表：

- Web 后端起来了
- 你可以通过网页去启动建图或导航栈

真正的建图/导航节点，是网页按钮再去拉起的。

### 7.2 建图模式和导航模式不是同时开的

正常流程是：

1. 建图模式扫图
2. 保存地图
3. 停掉建图模式
4. 切到导航模式
5. 加载地图并设初始位姿

### 7.3 建图时地图上不一定能看到机器人图标

当前建图模式下，前端主位姿显示不是完全针对建图体验设计的。
所以你看到“能扫图，但机器人图标不明显或不显示”，不一定代表系统挂了。

### 7.4 当前建图质量不是最终量产水平

当前建图链更偏验证和联调，强依赖 `/odom` 质量。
如果你扫图很快、急转多、场地特征少，地图会很糊。

---

## 8. 最常用的排查命令

### 8.1 看后端是不是活着

```bash
curl http://127.0.0.1:8080/api/health
```

### 8.2 看当前栈状态

```bash
curl http://127.0.0.1:8080/api/stack/status
```

### 8.3 看容器日志

```bash
docker logs --tail 200 docker-a2-system-ws-1
```

### 8.4 看当前是否还有残留 ROS 进程

```bash
pgrep -af "bringup.launch.py|a2_sdk_bridge|a2_control_bridge|manual_localization_publisher|goal_bridge|map_server|bt_navigator|planner_server|controller_server|velocity_smoother|lifecycle_manager|occupancy_mapper|map_manager"
```

### 8.5 强制停掉当前栈

```bash
curl -X POST http://127.0.0.1:8080/api/stack/stop
```

---

## 9. 如果网页打不开

先检查容器：

```bash
docker ps
```

再检查端口：

```bash
curl http://127.0.0.1:8080/api/health
```

如果本机能通、别的电脑打不开，再检查：

- A2 当前 IP 是否还是 `192.168.31.49`
- 你电脑和 A2 是否在同一局域网

---

## 10. 如果导航模式能起，但任务老失败

优先怀疑这几类问题：

1. 地图本身建得很差
2. 初始位姿设错了
3. 目标点点在障碍区
4. `/odom` 漂移导致定位变差

先不要一上来点远目标。正确做法是：

1. 先设初始位姿
2. 先点一个很近的短程目标
3. 先验证“机器人会动、会停、会结束”

---

## 11. 一条最短的成功路径

如果你什么都不想想，只想先跑起来，就照抄下面这组：

### 11.1 A2 终端

```bash
ssh unitree@192.168.31.49
cd /home/unitree/a2_system_ws
docker compose -f docker/docker-compose.a2.yml down
./docker/build_real_image.sh
docker compose -f docker/docker-compose.a2.yml up -d --force-recreate
curl http://127.0.0.1:8080/api/health
```

### 11.2 浏览器

打开：

```text
http://192.168.31.49:8080/
```

### 11.3 做导航

1. 选择右侧地图
2. 点击“启动导航模式”
3. 点击地图设置初始位姿
4. 再点击地图设置目标点
5. 发送导航

---

## 12. 当前推荐你这样用

如果你是第一次接手，建议顺序是：

1. 先把容器启动起来
2. 先看网页能不能打开
3. 先试“启动导航模式”
4. 看左侧节点是不是都 `running`
5. 再设初始位姿
6. 最后再发一个很近的目标点

不要一上来就：

- 重建新地图
- 发远距离目标
- 反复来回切模式

先把最小闭环跑通，再做复杂操作。
